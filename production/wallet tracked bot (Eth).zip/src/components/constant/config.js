const CONFIG = {
    NODE_URL: 'https://mainnet.infura.io/v3/9aa3d95b3bc440fa88ea12eaa4456161',
    EXPLORER: 'https://etherscan.io/tx/',
    EXPLORER_ADDR: 'https://etherscan.io/address/',
  }
  
  export default CONFIG