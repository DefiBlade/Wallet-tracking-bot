const CONFIG = {
    NODE_URL: 'wss://bsc-ws-node.nariox.org:443',
    EXPLORER: 'https://etherscan.io/tx/',
    EXPLORER_ADDR: 'https://etherscan.io/address/',
  }
  
  export default CONFIG